﻿using InterfaceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static InterfaceLayer.ProductsModel;
using static InterfaceLayer.ProductTypeModel;

namespace InterfaceLayer
{
    public class ProductViewModel
    {
        
        public List<Producttype> productTypeModel { get; set; }
        public List<Products> productModel { get; set; }
        public List<ProductCustomModel> productToppingsModel { get; set; }
        public double totalAmount { get; set; }
    }
}
