﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
 

namespace InterfaceLayer
{
    public class ProductsModel
    {
        public class Products
        {
            public int productId { get; set; }
            public int productTypeId { get; set; }
            public string productName { get; set; }
            public string productImage { get; set; }
            public int productPrice { get; set; }
        }
        public List<Products> lstProducts = new List<Products>() {
            new Products() { productId=1, productTypeId=1, productName="Veg Mexican Pizza", productPrice=300,productImage="Pizza.jpg" }
        ,new Products() { productId=2, productTypeId=1, productName="Veg FarmHouse Pizza", productPrice=400,productImage="Pizza.jpg" }
            ,new Products() { productId=3, productTypeId=2, productName=" Frento Grilled Sandwitch", productPrice=100,productImage="Sanwitches.jpg" }
            ,new Products() { productId=4, productTypeId=2, productName=" Baked Sandwitch", productPrice=100, productImage="Sanwitches.jpg"}
            ,new Products() { productId=5, productTypeId=2, productName=" Moyoins Sandwitch", productPrice=100,productImage="Sanwitches.jpg" }
            ,new Products() { productId=6, productTypeId=3, productName="Fanta", productPrice=60,productImage="Drink.jpg" }
            ,new Products() { productId=7, productTypeId=3, productName="Coke", productPrice=60,productImage="Drink.jpg" }
            ,new Products() { productId=8, productTypeId=3, productName="Thumbs up", productPrice=60,productImage="Drink.jpg" }
        };


    }
}
