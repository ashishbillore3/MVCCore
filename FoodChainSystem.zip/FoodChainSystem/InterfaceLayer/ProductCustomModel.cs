﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static InterfaceLayer.Base;

namespace InterfaceLayer
{
    public class ProductCustomModel
    {

        public int? ProductTypeId { get; set; }
        public string CustomName { get; set; }
        public int CustomPrice { get; set; }
        public CustomType customType { get; set; }
    }
}
