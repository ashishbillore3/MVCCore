﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterfaceLayer
{
    public class ProductTypeModel
    {
        public class Producttype
        {
            public int ProductTypeId { get; set; }
            public string productName { get; set; }
        }

       

    }

}
