﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterfaceLayer
{
    public class Base
    {
        public enum CustomType { Base=1,Bread,Topping,Sauce,Cheese }
    }
}
