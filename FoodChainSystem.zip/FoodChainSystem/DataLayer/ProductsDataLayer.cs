﻿using InterfaceLayer;
using System;
using System.Collections.Generic;
using System.Text;
using static InterfaceLayer.Base;
using static InterfaceLayer.ProductsModel;
using static InterfaceLayer.ProductTypeModel;

namespace DataLayer
{
    public class ProductsDataLayer
    {
        public List<Producttype>  getProductType()
        {
            List<Producttype> lstProductType = new List<Producttype>() { new Producttype() { ProductTypeId = 1, productName = "Pizza" },
                new Producttype() { ProductTypeId = 2, productName = "Sandwitches" },
                new Producttype() { ProductTypeId = 3, productName = "Drink" }};
            return lstProductType;
        }
        public List<Products> getProducts()
        {
            List<Products> lstProducts = new List<Products>() {
                 new Products() { productId=1, productTypeId=1, productName="Veg Mexican Pizza", productPrice=300,productImage="Pizza.jpg" }
                ,new Products() { productId=2, productTypeId=1, productName="Veg FarmHouse Pizza", productPrice=400,productImage="Pizza.jpg" }
                ,new Products() { productId=3, productTypeId=2, productName=" Frento Grilled Sandwitch", productPrice=100,productImage="Sanwitches.jpg" }
                ,new Products() { productId=4, productTypeId=2, productName=" Baked Sandwitch", productPrice=100, productImage="Sanwitches.jpg"}
                ,new Products() { productId=5, productTypeId=2, productName=" Moyoins Sandwitch", productPrice=100,productImage="Sanwitches.jpg" }
                ,new Products() { productId=6, productTypeId=3, productName="Fanta", productPrice=60,productImage="Drink.jpg" }
                ,new Products() { productId=7, productTypeId=3, productName="Coke", productPrice=60,productImage="Drink.jpg" }
                ,new Products() { productId=8, productTypeId=3, productName="Thumbs up", productPrice=60,productImage="Drink.jpg" }
            };
            return lstProducts;
        }
        public ProductViewModel getProductView()
        {
            ProductViewModel productViewModel = new ProductViewModel();
            productViewModel.productModel = new List<Products>();
            productViewModel.productModel = getProducts();
            productViewModel.productTypeModel = new List<Producttype>();
            productViewModel.productTypeModel = getProductType();

            List<ProductCustomModel> lstTopping = new List<ProductCustomModel>() {
                 new ProductCustomModel {   customType=CustomType.Topping, CustomName= "Pepperoni.",CustomPrice=20 }
               ,  new ProductCustomModel { customType=CustomType.Topping,CustomName= "Mushrooms.",CustomPrice=20 }
               ,  new ProductCustomModel { customType=CustomType.Topping,CustomName= "Onions.",CustomPrice=20 }
               ,  new ProductCustomModel { customType=CustomType.Topping,CustomName= "Sausage.",CustomPrice=20 }
               ,  new ProductCustomModel { customType=CustomType.Topping,CustomName= "Bacon.",CustomPrice=20 }
               ,  new ProductCustomModel { customType=CustomType.Topping,CustomName= "Extra cheese.",CustomPrice=20 }
               ,  new ProductCustomModel { customType=CustomType.Topping,CustomName= "Black olives.",CustomPrice=20 }
               , new ProductCustomModel {  ProductTypeId=1,  customType=CustomType.Base, CustomName= "Thin Crust",CustomPrice=10 }
               ,  new ProductCustomModel { ProductTypeId=1, customType=CustomType.Base,CustomName= "Cheese Burst",CustomPrice=10 }
                   , new ProductCustomModel {   customType=CustomType.Sauce, CustomName= "Red Sauce",CustomPrice=10 }
               ,  new ProductCustomModel { customType=CustomType.Sauce,CustomName= "White Sauce",CustomPrice=10 }
               ,  new ProductCustomModel { customType=CustomType.Cheese,CustomName= "Mozirilla Cheese",CustomPrice=10 }
               ,  new ProductCustomModel { customType=CustomType.Cheese,CustomName= "Mouyonize",CustomPrice=10 }
                              ,  new ProductCustomModel { ProductTypeId=2, customType=CustomType.Bread,CustomName= "White bread",CustomPrice=10 }
               ,  new ProductCustomModel { ProductTypeId=2, customType=CustomType.Bread,CustomName= "Brown bread",CustomPrice=10 }
            };
            productViewModel.productToppingsModel = new List<ProductCustomModel>();
            productViewModel.productToppingsModel = lstTopping;
            return productViewModel;
        }

    }
}
