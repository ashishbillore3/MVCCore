﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using static InterfaceLayer.ProductTypeModel;
using static InterfaceLayer.ProductsModel;
using static InterfaceLayer.Base;
using InterfaceLayer;
using Businesslayer;

namespace FoodChainSystem.Controllers
{
    public class ProductsController : Controller
    {

        [HttpGet]
        public IActionResult ViewProducts()
        {
            ProductsBusinessLayer objBLL = new ProductsBusinessLayer();

            return View(objBLL.getProductView());
        }

        public IActionResult Modifyproduct()
        {

            return View();
        }
        public ActionResult Admin()
        {
            ProductsBusinessLayer objBLL = new ProductsBusinessLayer();
            List<Products> lst = objBLL.getProducts();
            return View(lst);
        }
        public IActionResult CheckOut(string TotalValue)
        {

            return Content("Thank you! Order has been confirm. We have received amount " + TotalValue);
        }

    }
}








