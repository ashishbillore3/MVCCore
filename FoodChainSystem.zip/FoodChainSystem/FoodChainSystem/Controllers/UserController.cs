﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace FoodChainSystem.Controllers
{
    public class UserController : Controller
    {
       
        [HttpGet]
        public IActionResult Login()
        {
         return View();
        }
        [HttpPost]
        [ActionName("Login")]
        public IActionResult Login_Post(string username,string password)
        {
            if (username == "admin" && password == "password")
            {
                return RedirectToAction("Admin", "Products");
            }
            else
            {
                ViewBag.Message = "Please enter admin as username and password as password";
            }
            return View();
        }
    }
}