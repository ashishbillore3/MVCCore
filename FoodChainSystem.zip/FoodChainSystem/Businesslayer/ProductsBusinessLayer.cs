﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer;
using InterfaceLayer;
using static InterfaceLayer.ProductsModel;

namespace Businesslayer
{
    public class ProductsBusinessLayer
    {
        public ProductViewModel getProductView()
        {
            ProductsDataLayer productsDataLayer = new ProductsDataLayer();

          
            return productsDataLayer.getProductView();
        }
        public List<Products> getProducts()
        {
            ProductsDataLayer productsDataLayer = new ProductsDataLayer();
            return productsDataLayer.getProducts();
        }
        
    }
}
